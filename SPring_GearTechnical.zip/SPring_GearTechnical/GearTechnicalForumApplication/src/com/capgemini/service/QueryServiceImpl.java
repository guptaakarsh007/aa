
package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.QueryMaster;
import com.capgemini.exception.InvalidInputException;
import com.capgemini.repo.QueryRepo;

@Service
public class QueryServiceImpl implements QueryService {

	@Autowired
	private QueryRepo repo;

	@Override
	public QueryMaster fetchQuery(int query_id) throws InvalidInputException {
		QueryMaster querymaster = repo.findOne(query_id);
		if (querymaster == null) {
			throw new InvalidInputException();
		}
		return querymaster;
	}

	@Override
	public QueryMaster updateQuery(QueryMaster querymaster) {
		
		if(repo.equals(querymaster)){
			System.out.println("Hi");
			return repo.save(querymaster);
		}
		return null;
	}

}