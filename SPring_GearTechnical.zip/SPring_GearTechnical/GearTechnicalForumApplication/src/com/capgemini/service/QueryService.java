package com.capgemini.service;

import com.capgemini.beans.QueryMaster;
import com.capgemini.exception.InvalidInputException;

public interface QueryService {

	public QueryMaster updateQuery(QueryMaster querymaster);

	public QueryMaster fetchQuery(int query_id) throws InvalidInputException;

}
