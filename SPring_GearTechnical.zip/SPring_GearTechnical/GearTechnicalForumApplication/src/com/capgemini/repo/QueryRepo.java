package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.beans.QueryMaster;

@Repository
public interface QueryRepo extends CrudRepository<QueryMaster, Integer> {

	/*@Query("Update QueryMaster q set q.solutions=:solutions,q.solution_given_by=:solution_given_by where q.query_id=:query_id")
	public QueryMaster update(@Param("query_id") int query_id, @Param("solutions") String solutions,
			@Param("solution_given_by") String solution_given_by);*/
}
