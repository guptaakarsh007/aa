
package com.capgemini.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.beans.QueryMaster;
import com.capgemini.exception.InvalidInputException;
import com.capgemini.service.QueryService;

@Controller
public class QueryActionController {
	@Autowired
	private QueryService queryService;

	@RequestMapping(value = "/querydet")
	public String search(@Valid @RequestParam("query_id") int query_id, Model model) {
		QueryMaster querymaster = null;
		try {
			querymaster = queryService.fetchQuery(query_id);
			System.out.println(querymaster);
		} catch (InvalidInputException e) {
			model.addAttribute("query_id", query_id);
			return "errorpage";
		}
		model.addAttribute("querymaster", querymaster);
		return "querydetails";
	}

	@RequestMapping(value = "/querydetails", method = RequestMethod.POST)
	public String queryDetails(HttpServletRequest req, Model m) {
		QueryMaster querymaster = new QueryMaster(Integer.parseInt(req.getParameter("query_id")),
				req.getParameter("technology"), req.getParameter("query_raised_by"), req.getParameter("queryquestion"),
				req.getParameter("solutions"), req.getParameter("solution_given_by"));
//		System.out.println(querymaster);
		querymaster = queryService.updateQuery(querymaster);
		m.addAttribute("querymaster", querymaster);
		return "submitsuccessfully";
	}
}
