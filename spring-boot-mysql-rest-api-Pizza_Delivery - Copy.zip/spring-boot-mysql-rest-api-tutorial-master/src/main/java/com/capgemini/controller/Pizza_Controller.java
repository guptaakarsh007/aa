package com.capgemini.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.InvalidInputException;
import com.capgemini.model.Pizza_Menu;
import com.capgemini.model.Pizza_Order;
import com.capgemini.service.Pizza_Service;
import com.capgemini.service.Pizza_Service_Impl;


@RestController
@RequestMapping("/api")
public class Pizza_Controller {

    @Autowired
    Pizza_Service pizzaService;
   
    

    @RequestMapping(method=RequestMethod.GET, value="/getPizza")
    public List<Pizza_Menu> getAllPizza() {
        return pizzaService.getPizzaMenu();
    }
    
    @RequestMapping(method=RequestMethod.POST, value="/addPizzaMenu/{pizzaId}/{pizzaName}/{pizzaPrice}")
    public Pizza_Menu addPizzaMenu(@PathVariable  Long pizzaId,@PathVariable String pizzaName,@PathVariable int pizzaPrice )  
	{
		
		return pizzaService.addPizzaMenu(pizzaId,pizzaName,pizzaPrice);
		
	}
    
    @RequestMapping(method=RequestMethod.GET, value="/getOrderDetails")
    public List<Pizza_Order> getOrderDetails() {
        return pizzaService.getOrderDetails();
    }
    
    @RequestMapping(method=RequestMethod.POST, value="/addOrderDetails/{orderId}/{pizzaId}/{customerName}/{customerAddress}/{customerPhoneNo}")
    public Pizza_Order addPizzaMenu(@PathVariable Long orderId,@PathVariable int pizzaId,@PathVariable String customerName,@PathVariable String customerAddress,@PathVariable String customerPhoneNo )  
	{
		
		return pizzaService.addPizzaMenu(orderId,pizzaId,customerName,customerAddress,customerPhoneNo);
		
	}
    
    @RequestMapping(method=RequestMethod.GET, value="/viewOrderDetails/{orderId}")
    public Optional<Pizza_Order> viewOrderDetail(@PathVariable Long orderId) throws InvalidInputException
    {
    	 return pizzaService.viewOrderDetails(orderId);
    }
    
	/*
	 * @PostMapping("/notes") public Pizza_Menu createNote(@Valid @RequestBody
	 * Pizza_Menu note) { return noteRepository.save(note); }
	 * 
	 * @GetMapping("/notes/{id}") public Pizza_Menu getNoteById(@PathVariable(value
	 * = "id") Long noteId) { return noteRepository.findById(noteId) .orElseThrow(()
	 * -> new ResourceNotFoundException("Note", "id", noteId)); }
	 * 
	 * @PutMapping("/notes/{id}") public Pizza_Menu updateNote(@PathVariable(value =
	 * "id") Long noteId,
	 * 
	 * @Valid @RequestBody Pizza_Menu noteDetails) {
	 * 
	 * Pizza_Menu note = noteRepository.findById(noteId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Note", "id", noteId));
	 * 
	 * note.setTitle(noteDetails.getTitle());
	 * note.setContent(noteDetails.getContent());
	 * 
	 * Pizza_Menu updatedNote = noteRepository.save(note); return updatedNote; }
	 * 
	 * @DeleteMapping("/notes/{id}") public ResponseEntity<?>
	 * deleteNote(@PathVariable(value = "id") Long noteId) { Pizza_Menu note =
	 * noteRepository.findById(noteId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Note", "id", noteId));
	 * 
	 * noteRepository.delete(note);
	 * 
	 * return ResponseEntity.ok().build(); }
	 */
}
