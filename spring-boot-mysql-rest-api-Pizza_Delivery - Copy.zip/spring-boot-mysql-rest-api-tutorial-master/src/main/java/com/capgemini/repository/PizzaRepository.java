package com.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.model.Pizza_Menu;



@Repository
public interface PizzaRepository extends JpaRepository<Pizza_Menu, Long> {

}
