package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Entity
@Table(name = "pizza_menu")
//@EntityListeners(AuditingEntityListener.class)
/*
 * //@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters =
 * true)
 */
public class Pizza_Menu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pizzaId;

    //@NotBlank
    private String pizzaName;

    //@NotBlank
    private int pizzaPrice;

	/**
	 * @return the pizzaId
	 */
	public Long getPizzaId() {
		return pizzaId;
	}

	/**
	 * @param pizzaId the pizzaId to set
	 */
	public void setPizzaId(Long pizzaId) {
		this.pizzaId = pizzaId;
	}

	/**
	 * @return the pizzaName
	 */
	public String getPizzaName() {
		return pizzaName;
	}

	/**
	 * @param pizzaName the pizzaName to set
	 */
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	/**
	 * @return the pizzaPrice
	 */
	public int getPizzaPrice() {
		return pizzaPrice;
	}

	/**
	 * @param pizzaPrice the pizzaPrice to set
	 */
	public void setPizzaPrice(int pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}

}